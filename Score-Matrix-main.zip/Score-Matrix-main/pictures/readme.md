This folder is not required to run the project; it only contains images used in the GitHub README.
